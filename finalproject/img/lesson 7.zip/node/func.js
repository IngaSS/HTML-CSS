let a = par => {
    let var1 = 10;
    return (var1 + par)
};

// module.exports = a;

let b = par => {
    console.log (`Hello, ${par}`)
}

// module.exports = {
//     a: a,
//     b: b
// };

module.exports = {
    a, b
}