// let a = 10;
// let b = 5;
// console.log (a * b);

// const func = require ('./func');

//console.log (func (100));


// console.log (func.a(500));
// console.log (func.b('USERname'));

// const os = require ('os');
//
// console.log (os.platform());
// console.log (os.cpus());

const fs = require ('fs');

//Создание файлов
let users = [{name: 'Андрей', age: 21}];
let user1 = '{"name": "Ann", "age": 34}';

// fs.writeFile ('db.json', JSON.stringify(users), (error) => {
//     if (error) {
//         console.log (error);
//     }
// })
// Чтение и дополнение файлов

// fs.readFile ('db.json', 'utf-8', (error, data) => {
//     if (error) {
//         console.log (error);
//     } else {
//         let users = JSON.parse (data);
//         users.push (JSON.parse(user1));
//         fs.writeFile ('db.json', JSON.stringify(users), (error) => {
//             if (error) {
//                 console.log (error);
//             }
//         })
//     }
// })

// HTTP
// const http = require ('http');
//
// const server = http.createServer ((req, res) => {
//     if (req.url === '/') {
//         res.write ('Hello stalker');
//         res.end ();
//     }
//     if (req.url === '/users') { //lh://3000/users
//         res.write (JSON.stringify(users));
//         res.end();
//     }
// });
//
// server.listen (3000);
// server.on ('connection', (socket) => {
//     console.log ('New connection')
// });
// console.log ('server listen at port 3000...');

const moment = require ('moment');
console.log (moment().format('MMMM Do YYYY, h:mm:ss a'));